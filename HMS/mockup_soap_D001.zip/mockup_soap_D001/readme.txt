






---------------------------------Free-psd-templates.com-----------------------------------------








Hello! Thanks a lot for downloading the flyer, I hope it will be of service to you.

----------------------------------------------------------------------------------

PSD is set up in 3000�2400 dimension.
You can easily change texts, content, images, objects and color palette.
The PSD file is very well organised, with color coded groups and layers named appropriately.


<<<<<<<<<<<<<<<<<<<<<<Free fonts used in design:>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

1) Freshman http://www.dafont.com/freshman.font


<<<<<<<<<<<<<<<<<<<<<< How  to update (change) the main image >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

1) Make sure that your layers palette ( Window --> Layers) is opened.
2) Choose the layer  �YOUR IMAGES HERE >>> Right click >>> Edit Content�, right click on the layer, select �Edit content�.
3) Change the blurred image to yours.
4) Close the window. Confirm the changes by clicking ��es�
 

----------------------------------------------------------------------------------


Our team thanks you again for  purchasing  the  flyer.

We are always happy to help you. 






---------------------------------Free-psd-templates.com-----------------------------------------
